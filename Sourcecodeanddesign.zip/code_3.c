#include <stdio.h>

int minChanged(char spellChart[][20], int n);
int minRevEdgeCount(int mask, int n, int* M, int* hasEdge);

int min(int a, int b)
{
	if (a < b)
		return a;
	return b;
}

int main() 
{
	char spellChart[20][20];
	int n; 			
	
	// Get input
	scanf("%d", &n);
	int i;
	for(i = 0; i<n; i++)
		scanf("%s",spellChart[i]);
	
	
	printf("Ans: %d.\n", minChanged(spellChart, n));  

}

int minChanged(char spellChart[][20], int n)
{
	int hasEdge[22]; 	// bitmask of all verticies which have edges from current vertex
	//Initilize bitmasks for all vertices
	int i;
	for(i = 0; i < n; ++i)
	{
		hasEdge[i] = 0;
		int j;
		for(j = 0; j < n; ++j)
		{
			if(spellChart[i][j] == 'Y')
			{
				hasEdge[i] |= (1<<j);
			}
		}
	}

	int M[1<<20]; 				// The lookup table
	//initilize all entries the lookup table to -1
	for(i = 0; i< 1<<20; i++)
		M[i] = -1;

	return minRevEdgeCount(0, n, M, hasEdge);
}

// minRevEdgeCount returns the minimum number of changes 
// to be made to make the spellChart topologically sorted 

int minRevEdgeCount(int mask, int n, int* M, int* hasEdge){
	if(mask == ((1<<n)-1))   // End condition 1: mask is all 1s
	{ 
		return 0;
    	}
	if(M[mask]>-1) 		// End condition 2: Required value for this mask was already calculated before
		return M[mask];
	M[mask] = 1<<29; //Initially set to infinity

	int i;
	for(i = 0; i < n; ++i)
	{
		if(!((mask>>i)&1))
		{
			int nextMask = mask|(1<<i);
			int revEdgeCount = 0;
			int k = nextMask&hasEdge[i]; 	//nextMask&hasEdge[i] will have 1s for each reverse edge
			// counting the number of reverse edges (1s)
			for(k = nextMask&hasEdge[i]; k>0; k>>=1) 
			{
				revEdgeCount += (k&1);
			}
			
			M[mask] = min(M[mask], revEdgeCount + minRevEdgeCount(mask|(1<<i), n, M, hasEdge));
		}
	}

	return M[mask];
}

